# Countdown Timer

A simple countdown timer built using HTML, CSS, and JavaScript that allows users to input a time in `MM:SS` format, start, pause, and reset the timer.

## Features

- Input countdown time in `MM:SS` format.
- Start the timer.
- Pause and resume the timer.
- Reset the timer to the newly inputted time.
- Warning message (red color) when the timer reaches 10 seconds.
- The timer will resume from the last paused time instead of resetting to the initial value.

## Installation

1. Clone the repository or download the files.
2. Open `index.html` in your browser.

## Usage

1. **Enter Time**: In the input field, type the time in `MM:SS` format.
2. **Start Timer**: Click the "Start" button to begin the countdown.
   - If the timer is paused, clicking "Start" will **resume** from where it left off.
   - If the timer is not started yet, it will begin from the inputted time.
3. **Pause Timer**: Click the "Pause" button to pause the timer.
4. **Reset Timer**: Click the "Reset" button to reset the timer to the newly inputted time.
   - You can update the input time and reset the countdown to that new value.

## File Structure

- `index.html` - The main HTML file.
- `style.css` - The CSS file for styling.
- `script.js` - The JavaScript file that contains the countdown logic.
- `README.md` - This file.

## Technologies Used

- HTML
- CSS
- JavaScript

## Troubleshooting

- If the input format is incorrect (not MM:SS), an error message will prompt asking you to use the correct format.
- The timer will automatically stop when the countdown reaches 0.
- If the timer is paused, the "Start" button will resume from the current time instead of restarting.

## Contact

For any questions or feedback, feel free to reach out to [malekkhaledsaleh@gmail.com].
