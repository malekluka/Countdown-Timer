let timer;
let totalTime = 0;
let timeLeft = 0;
let isPaused = false; // Flag to check if the timer is paused

const timeInput = document.getElementById('timeInput');
const timerDisplay = document.getElementById('timerDisplay');
const startBtn = document.getElementById('startBtn');
const pauseBtn = document.getElementById('pauseBtn');
const resetBtn = document.getElementById('resetBtn');

// Convert MM:SS to total seconds
function parseTime(input) {
    const parts = input.split(':');
    if (parts.length !== 2) return NaN;
    const minutes = parseInt(parts[0], 10);
    const seconds = parseInt(parts[1], 10);
    if (
        isNaN(minutes) ||
        isNaN(seconds) ||
        seconds >= 60 ||
        minutes < 0 ||
        seconds < 0
    ) {
        return NaN;
    }
    return minutes * 60 + seconds;
}

// Update the timer display
function updateDisplay(seconds) {
    const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    timerDisplay.textContent = `${minutes}:${secs}`;
    if (seconds <= 10) {
        timerDisplay.classList.add('warning');
    } else {
        timerDisplay.classList.remove('warning');
    }
}

// Start or resume the countdown
function startTimer() {
    if (!isPaused) {
        const inputTime = parseTime(timeInput.value); // Get the current input value
        if (isNaN(inputTime)) {
            alert('Invalid time format. Please use MM:SS.');
            return;
        }
        totalTime = timeLeft = inputTime; // Set total time and time left from the input field
    }

    if (timer) {
        clearInterval(timer); // Ensure that any existing timer is cleared before starting a new one
    }

    isPaused = false; // Timer is no longer paused

    timer = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(timer);
            alert("Time's up!");
        } else {
            timeLeft--;
            updateDisplay(timeLeft);
        }
    }, 1000);
}

// Pause the countdown
function pauseTimer() {
    clearInterval(timer);
    isPaused = true; // Set the flag to paused
}

// Reset the countdown to the current input time
function resetTimer() {
    const inputTime = parseTime(timeInput.value); // Get the current input value from the input field
    if (isNaN(inputTime)) {
        alert('Invalid time format. Please use MM:SS.');
        return;
    }
    totalTime = timeLeft = inputTime; // Reset the time based on the input value
    updateDisplay(timeLeft || 0); // Update the display
    clearInterval(timer); // Clear the existing timer
    isPaused = false; // Reset paused state
}

startBtn.addEventListener('click', startTimer);
pauseBtn.addEventListener('click', pauseTimer);
resetBtn.addEventListener('click', resetTimer);
